﻿using System;
using System.Collections.Generic;
using System.Text;

using System.ComponentModel;

namespace PlaylistBox
{
    public class ChatListSubItemConverter : ExpandableObjectConverter
    {
    }
}
